import java.sql.*;
import java.util.Scanner;

public class StudentManagementJDBC {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Student Management System ---");
            System.out.println("1. Add Student");
            System.out.println("2. View Students");
            System.out.println("3. Search Student");
            System.out.println("4. Update Student");
            System.out.println("5. Delete Student");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();
            sc.nextLine();

            try (Connection con = DBConnection.getConnection()) {
                switch (choice) {
                    case 1:
                        System.out.print("Enter name: ");
                        String name = sc.nextLine();
                        System.out.print("Enter email: ");
                        String email = sc.nextLine();
                        System.out.print("Enter branch: ");
                        String branch = sc.nextLine();
                        System.out.print("Enter age: ");
                        int age = sc.nextInt();
                        sc.nextLine();

                        String insert = "INSERT INTO student (name, email, branch, age) VALUES (?, ?, ?, ?)";
                        try (PreparedStatement ps = con.prepareStatement(insert)) {
                            ps.setString(1, name);
                            ps.setString(2, email);
                            ps.setString(3, branch);
                            ps.setInt(4, age);
                            ps.executeUpdate();
                            System.out.println("Student added successfully!");
                        }
                        break;

                    case 2:
                        try (Statement st = con.createStatement();
                             ResultSet rs = st.executeQuery("SELECT * FROM student")) {
                            while (rs.next()) {
                                System.out.println(
                                    rs.getInt("id") + " | " +
                                    rs.getString("name") + " | " +
                                    rs.getString("email") + " | " +
                                    rs.getString("branch") + " | " +
                                    rs.getInt("age"));
                            }
                        }
                        break;

                    case 3:
                        System.out.print("Enter student ID: ");
                        int searchId = sc.nextInt();
                        sc.nextLine();

                        try (PreparedStatement ps = con.prepareStatement(
                                "SELECT * FROM student WHERE id = ?")) {
                            ps.setInt(1, searchId);
                            try (ResultSet rs = ps.executeQuery()) {
                                if (rs.next()) {
                                    System.out.println(
                                        rs.getInt("id") + " | " +
                                        rs.getString("name") + " | " +
                                        rs.getString("email") + " | " +
                                        rs.getString("branch") + " | " +
                                        rs.getInt("age"));
                                } else {
                                    System.out.println("Student not found.");
                                }
                            }
                        }
                        break;

                    case 4:
                        System.out.print("Enter student ID to update: ");
                        int updateId = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter new email: ");
                        String newEmail = sc.nextLine();
                        System.out.print("Enter new age: ");
                        int newAge = sc.nextInt();
                        sc.nextLine();

                        try (PreparedStatement ps = con.prepareStatement(
                                "UPDATE student SET email = ?, age = ? WHERE id = ?")) {
                            ps.setString(1, newEmail);
                            ps.setInt(2, newAge);
                            ps.setInt(3, updateId);
                            int rows = ps.executeUpdate();
                            System.out.println(rows > 0
                                ? "Student updated successfully!"
                                : "Student not found.");
                        }
                        break;

                    case 5:
                        System.out.print("Enter student ID to delete: ");
                        int deleteId = sc.nextInt();
                        sc.nextLine();

                        try (PreparedStatement ps = con.prepareStatement(
                                "DELETE FROM student WHERE id = ?")) {
                            ps.setInt(1, deleteId);
                            int rows = ps.executeUpdate();
                            System.out.println(rows > 0
                                ? "Student deleted successfully!"
                                : "Student not found.");
                        }
                        break;

                    case 6:
                        System.out.println("Exiting Student Management System.");
                        sc.close();
                        return;

                    default:
                        System.out.println("Invalid choice. Try again.");
                }
            } catch (SQLException e) {
                System.out.println("Database error: " + e.getMessage());
            }
        }
    }
}

